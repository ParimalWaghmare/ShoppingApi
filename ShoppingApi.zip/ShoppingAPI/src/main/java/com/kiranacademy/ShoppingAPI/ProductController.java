package com.kiranacademy.ShoppingAPI;

import java.util.Arrays;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.NativeQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("productapi")
public class ProductController {
	@Autowired
	SessionFactory factory;
	
	@PostMapping("product/{category_id}")
	public Product addProduct(@RequestBody Product product,@PathVariable int category_id)
	{
		System.out.println("Category id is " + category_id);
		
		Session session=factory.openSession();
		
		Category category=session.load(Category.class,category_id);
				
		
		/* get list of product and add product into it  */
		
		List<Product> productlist=category.getProducts();
			
		
		Transaction transaction=session.beginTransaction();
		
			productlist.add(product);
						
		transaction.commit();
		
		
		System.out.println("product added into database");
		
		return product;
		
	
	}

	
	
	@DeleteMapping("product/{product_id}")
	public String deleteProduct(@PathVariable int product_id)
	{
		
		// To get Category Id of Product , we need to write join query 
		
		Session session=factory.openSession();
		
		NativeQuery<Object[]> query=session.createSQLQuery("select category.category_id  , category.category_name from category,product where product.category_id=category.category_id and product_id="+product_id);

		List<Object[]> list = query.list(); 
		
		// list [ (array having 2 values) only this single array is present in list ] 
		
		System.out.println(list.size());
		
		Object[] array=list.get(0);
		
		int category_id=(int)array[0];
		
	System.out.println(product_id + " " + category_id);
			
	
	
	// get Category object corresponding to above cid
		
        Category category=session.load(Category.class,category_id);
				
		
	
    /* get list of product and remove product from it  */
		
		
        List<Product> productlist=category.getProducts();
		
		

		Product product=session.load(Product.class,product_id);
				
		Transaction transaction=session.beginTransaction();
		
			productlist.remove(product);
						
		transaction.commit();
		
		
		return "record deleted";
				
	}
	
	
	@GetMapping("product/{product_id}")
	public String viewProduct(@PathVariable int product_id)
	{
		
				Session session=factory.openSession();
				
				NativeQuery<Object[]> query=session.createSQLQuery("select product.product_id,product.product_name,product.product_rate, category.category_id,category.category_name as cname from category,product where product.category_id=category.category_id and product_id="+product_id);

				List<Object[]> list = query.list(); 
				
				Object[] array=list.get(0);
				
				
				return Arrays.toString(array);
	}
	

	@GetMapping("product")
	public String getAllProducts()
	{
		
				Session session=factory.openSession();
				
				NativeQuery<Object[]> query=session.createSQLQuery("select product.product_id,product.product_name,product.product_rate, category.category_id ,category.category_name as cname from category,product where product.category_id=category.category_id");

				List<Object[]> list = query.list(); 
					
				StringBuffer stringBuffer=new StringBuffer();
				
				for(int i=0;i<list.size();i++)
				{
					Object[] array=list.get(i);
					
					stringBuffer.append(Arrays.toString(array) + " , ");
					
				}
				
				return stringBuffer.toString();
				
	}


	
	
	@PutMapping("product")
	public String updateProduct(@RequestBody Product clientProduct)
	{
		
				Session session=factory.openSession();
				
				
				Product product=session.load(Product.class,clientProduct.getProduct_id());
				
				product.setProduct_name(clientProduct.getProduct_name());
				
				product.setProduct_price(clientProduct.getProduct_rate());
				

				Transaction transaction=session.beginTransaction();
				
					session.update(product);
								
				transaction.commit();
				
				
				return "Record Updated";

	}

}

/*
 * The code starts with a class ProductController.
 This is the controller that handles requests for products from the ShoppingAPI.
 The code then imports classes and interfaces, which are needed to create an instance of SessionFactory and use it to open a session.
 The @RestController annotation tells Spring MVC that this class will handle HTTP GET requests for productapi/product/.
 It also uses annotations like @RequestMapping("productapi") to map URLs in the application to methods in this controller.
 Next, we have an import statement importing org.hibernate.Session; followed by an import statement importing org.springframework.beans.factory .annotation .Autowired; followed by another import statement importing org of springframework web bind annotation PathVariable; followed by yet another import statement importing org of spring framework web bind annotation RequestBody; followed by yet another import statement importing org of spring framework web bind annotation RequestMapping; followed by yet another import statement importing com .mysql jdbc driver ; finally ending with an annotated class ProductController (the one we just imported).
 The code is a part of the ProductController class.
 The code shows that the product is added to the database using Hibernate Session and then it is added to the list of products in Category.
 The code also shows how a transaction is created and committed before adding the product to the list of products in Category.
 The code starts by creating a Session object.
 The factory is then opened and the session is created.
 The code uses an @DeleteMapping annotation to delete a product from the database.
 The code first creates a category for the product, which will be used as input into join query in order to get Category Id of Product .
 Then it opens Session object and executes join query on that category with Product table using session's openSession() method.
 Finally, it deletes the product from database using deleteProduct() method defined in class DeleteMapping annotation.
 The code is a Java code that illustrates how to delete a product from the database.
 The first line of the code creates an instance of the Hibernate Session Factory.
 The next line gets the session object and assigns it to a variable named "session".
 The next line checks if there is any session object in memory by using "session" as an argument with "factory.openSession()".
 If there is no session object, then one will be created and assigned to "session".
 Next, we have a method called deleteProduct(), which takes in two arguments: product_id and category_id.
 We can get the category_id by writing a join query on table Category with product_
 The code starts by creating a SQLQuery object.
 The SQLQuery object is then used to create a list of all the categories and products in the database.
 The code then iterates through each category, printing out its name and ID number.
 It does this for every category until it gets to the product with an ID number equal to that of the current category's ID number.
 Once it has reached that point, it prints out just one item from that list: the first item in the list (array having 2 values).
 The code creates a NativeQuery object and then executes the query.
 The code iterates over the list of objects that are returned from the query.
 The code prints out the size of each list in order to show how many lists were found in the result set.
 The code starts by getting a Session object.
 The session is used to load the Category and Product objects corresponding to the category_id and product_id, respectively.
 The code then gets a list of all products in that category using the getProducts() method on the Category object.
 Next, it removes product from this list using remove(Product) method on List interface.
 Then commit changes made in transaction with commit().
 Finally, return "record deleted" string as response message for successful operation.
 The code is executed in the following manner: 1.
 The code gets the Category object corresponding to above cid.
 2.
 The code loads a list of Product objects from the Category object and removes the product from it.
 3.
 The code commits the transaction, which deletes all data related to that particular product from database table, if any exists.

 * */
