package com.kiranacademy.ShoppingAPI;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

@Entity
public class Category {
	
	@Id
	int category_id;
	String category_name;
	@OneToMany(targetEntity = Product.class,cascade = CascadeType.ALL, orphanRemoval = true)//, one-to-many mapping means that one row in a table is mapped to multiple rows in another table.
	@JoinColumn(name="category_id")
	List<Product> products;
	
	/*
	 * The code is trying to create a list of products that are associated with the category.
 The code is using @JoinColumn(name="category_id") to associate the category ID with each product.
 The code is also using CascadeType.ALL and orphanRemoval=true so that if there are no other categories in which this product belongs, then it will be removed from all other categories as well.
 The code is a JavaBean with two fields: category_id and category_name.
 The @OneToMany annotation indicates that the field products is a List of Product objects, which are annotated with @JoinColumn(name="category_id").
 The code above also has an additional annotation on it, indicating that the orphanRemoval attribute should be set to true.
 This means that if there are no other annotations or declarations on the class, then all instances of this class will have their own list of products added to them.
	 */
	
	
	public Category() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Category(int category_id, String category_name, List<Product> products) {
		super();
		this.category_id = category_id;
		this.category_name = category_name;
		this.products = products;
	}
	public int getCategory_id() {
		return category_id;
	}
	public void setCategory_id(int category_id) {
		this.category_id = category_id;
	}
	public String getCategory_name() {
		return category_name;
	}
	public void setCategory_name(String category_name) {
		this.category_name = category_name;
	}
	public List<Product> getProducts() {
		return products;
	}
	public void setProducts(List<Product> products) {
		this.products = products;
	}
	@Override
	public String toString() {
		return "Category [category_id=" + category_id + ", category_name=" + category_name + ", products=" + products
				+ "]";
	}

	
	
	
	

}
