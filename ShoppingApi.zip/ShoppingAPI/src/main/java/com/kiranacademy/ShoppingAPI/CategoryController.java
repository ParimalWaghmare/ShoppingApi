package com.kiranacademy.ShoppingAPI;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



@RestController
@RequestMapping("categoryapi")
public class CategoryController {
	
	@Autowired
	SessionFactory factory;
	
	@GetMapping("category/{category_id}")
	public Category getCategory(@PathVariable int category_id)
	{
		Session session = factory.openSession();
		
		Category category= session.load(Category.class, category_id);
		
		return category;
		
	}
	
	
	/**
	 * @return
	 */
	@GetMapping("category")
	public List<Category> getAllCategory()
	{
		Session session=factory.openSession();
		
		 Query query = session.createQuery("from Category");
		
		List<Category> list=query.list();
		
		
		return list;
		
	}
	
	
	
	@PostMapping("category")
	public Category addCategory(@RequestBody Category category)
	{
		
		Session session=factory.openSession();
		
		Transaction transaction=session.beginTransaction();
		
				session.save(category);
				
		transaction.commit();
		
		System.out.println("Category added into database");
			
		return category;
		
	}
	
	
	@DeleteMapping("category/{category_id}")
	public String deleteCategory(@PathVariable int category_id)
	{
	
		Session session=factory.openSession();
		
		Category category=session.load(Category.class, category_id);
		
		Transaction transaction=session.beginTransaction();
		
				session.delete(category);
				
		transaction.commit();
		
		return "record deleted";
	}
	
	
	@PutMapping("category")
	public String updatecategory(@RequestBody Category clientCategory)
	{
		
				Session session=factory.openSession();
				
				Category category=session.load(Category.class,clientCategory.getCategory_id());
				
				category.setCategory_name(clientCategory.getCategory_name());
				

				Transaction transaction=session.beginTransaction();
				
					session.update(category);
								
				transaction.commit();
				
				
				return "Record Updated";

	}

	
	
}
/*
 * The code is written in a class called CategoryController.
 It has two methods, one for getting categories and the other for adding new ones.
 The first method is getCategory() which takes an integer as its parameter and returns a category object from the database.
 The second method is getAllCategory(), which also takes no parameters but returns all of the categories that are available on our website.
 The code starts by importing some classes like SessionFactory, Transaction, Query, GetMapping etc., then it imports org.springframework annotations like @RestController to indicate that this class is a controller class and @RequestMapping("categoryapi") to indicate that it will be used with HTTP GET requests against /category/{category_id} where {category_id} represents the id of the category being requested (e.g., 1).
 Next we have two methods: addCategory() and getAllCategory().
 In addCategory(), we create a session using factory's openSession() method and save any data passed into it in there before committing changes back to Hibernate so they can be saved permanently on our server's database system; whereas in getAllCategories(), we use Hibernate's query language to retrieve all of
 The code is a controller that handles the category/{category_id} endpoint.
 The getCategory() method returns a Category object from the database based on the passed in parameter of category_id.
 The getAllCategory() method returns all categories from the database as a list.
 The addCategory() method adds a new category to the database and saves it with its own identifier.
 The code starts by declaring a Category class.
 The code then declares the deleteCategory() method that takes in an int category_id parameter and deletes the specified category from the database.
 The @DeleteMapping annotation is used to define a mapping for deleting categories.
 The @PathVariable annotation is used to specify which field of the Category object should be deleted, namely, its id field.
 Finally, the return value of this method will be "record deleted".
 The code is a mapping of the category to be inserted into the database.
 The code is a mapping of the category to be deleted from the database.

 */
	


